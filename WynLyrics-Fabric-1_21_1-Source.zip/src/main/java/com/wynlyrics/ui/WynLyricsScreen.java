package com.wynlyrics.ui;

import com.wynlyrics.config.WynConfig;
import com.wynlyrics.config.WynConfig.Config;
import com.wynlyrics.lyrics.FabricPaths;
import com.wynlyrics.lyrics.LrcPlayer;
import com.wynlyrics.render.FontRegistry;
import com.wynlyrics.render.WorldLyricsRenderer;
import com.wynlyrics.spotify.SpotifyAuth;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.List;

/** Main settings screen with tabs. Opens the HUD editor and the cosmetic editor. */
public final class WynLyricsScreen extends Screen {
    private enum Tab { GENERAL, SPOTIFY, LYRICS, ANIMATION, WORLD }

    private static Tab tab = Tab.GENERAL;
    private final Screen parent;
    private TextFieldWidget clientIdField;
    private SpotifyAuth.State shownState;

    public WynLyricsScreen(Screen parent) {
        super(Text.translatable("wynlyrics.screen.title"));
        this.parent = parent;
    }

    private int colX(int col) { return width / 2 - 156 + col * 158; }
    private static final int COL_W = 154;

    @Override
    protected void init() {
        FontRegistry.refresh();
        Config c = WynConfig.CONFIG;
        int cx = width / 2;
        shownState = SpotifyAuth.state();

        // tabs
        Tab[] tabs = Tab.values();
        int tw = 62, total = tabs.length * tw + (tabs.length - 1) * 2, x0 = cx - total / 2;
        for (int i = 0; i < tabs.length; i++) {
            Tab tb = tabs[i];
            ButtonWidget b = Ui.button(x0 + i * (tw + 2), 20, tw, Text.translatable("wynlyrics.tab." + tb.name().toLowerCase()), () -> {
                tab = tb;
                clearAndInit();
            });
            b.setHeight(18);
            b.active = tab != tb;
            addDrawableChild(b);
        }

        int top = 48;
        switch (tab) {
            case GENERAL -> {
                addDrawableChild(Ui.toggle(colX(0), top, COL_W, "wynlyrics.opt.hud", () -> c.hudEnabled, v -> c.hudEnabled = v));
                addDrawableChild(Ui.toggle(colX(1), top, COL_W, "wynlyrics.opt.hud3d", () -> c.hud3dEnabled, v -> c.hud3dEnabled = v));
                addDrawableChild(Ui.toggle(colX(0), top + 24, COL_W, "wynlyrics.opt.show_track", () -> c.showTrack, v -> c.showTrack = v));
                addDrawableChild(Ui.toggle(colX(1), top + 24, COL_W, "wynlyrics.opt.show_artist", () -> c.showArtist, v -> c.showArtist = v));
                addDrawableChild(Ui.toggle(colX(0), top + 48, COL_W, "wynlyrics.opt.show_progress", () -> c.showProgress, v -> c.showProgress = v));
                addDrawableChild(Ui.toggle(colX(1), top + 48, COL_W, "wynlyrics.opt.hide_idle", () -> c.hideWhenIdle, v -> c.hideWhenIdle = v));
                addDrawableChild(Ui.button(colX(0), top + 76, 312, Text.translatable("wynlyrics.opt.reset"), () -> {
                    WynConfig.resetKeepingSpotify();
                    clearAndInit();
                }));
            }
            case SPOTIFY -> initSpotify(c, top);
            case LYRICS -> {
                addDrawableChild(new ConfigSlider(colX(0), top, COL_W, 20, 0, 2, 1, () -> c.linesBefore, v -> c.linesBefore = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.lines_before", String.valueOf((int) v)), null));
                addDrawableChild(new ConfigSlider(colX(1), top, COL_W, 20, 0, 2, 1, () -> c.linesAfter, v -> c.linesAfter = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.lines_after", String.valueOf((int) v)), null));
                addDrawableChild(new ConfigSlider(colX(0), top + 24, 312, 20, -2000, 2000, 50, () -> c.lyricsOffsetMs, v -> c.lyricsOffsetMs = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.offset", ((int) v > 0 ? "+" : "") + (int) v + " ms"), null));
                addDrawableChild(Ui.toggle(colX(0), top + 48, 312, "wynlyrics.opt.per_track", () -> c.useSpotifyLyricsFile, v -> {
                    c.useSpotifyLyricsFile = v;
                    LrcPlayer.INSTANCE.reload();
                }));
                TextFieldWidget file = new TextFieldWidget(textRenderer, colX(0), top + 72, 208, 20, Text.translatable("wynlyrics.opt.lyrics_file"));
                file.setMaxLength(120);
                file.setText(c.lyricsFile);
                file.setChangedListener(s -> c.lyricsFile = s.isBlank() ? "current_song.lrc" : s.trim());
                addDrawableChild(file);
                addDrawableChild(Ui.button(colX(0) + 212, top + 72, 100, Text.translatable("wynlyrics.opt.reload"), () -> {
                    WynConfig.save();
                    LrcPlayer.INSTANCE.reload();
                }));
                addDrawableChild(Ui.button(colX(0), top + 96, 312, Text.translatable("wynlyrics.opt.open_folder"),
                        () -> Util.getOperatingSystem().open(FabricPaths.dir().toFile())));
            }
            case ANIMATION -> {
                addDrawableChild(Ui.cycle(colX(0), top, COL_W, "wynlyrics.opt.anim_type",
                        List.of("none", "fade", "slide", "zoom", "typewriter"), () -> c.animationType, v -> c.animationType = v,
                        v -> Text.translatable("wynlyrics.anim." + v)));
                addDrawableChild(new ConfigSlider(colX(1), top, COL_W, 20, 0, 1500, 50, () -> c.animationMs, v -> c.animationMs = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.anim_ms", (int) v + " ms"), null));
                addDrawableChild(new ConfigSlider(colX(0), top + 24, COL_W, 20, 0, 1500, 50, () -> c.hudFadeMs, v -> c.hudFadeMs = (int) v,
                        v -> Ui.labeled("wynlyrics.opt.hud_fade", (int) v + " ms"), null));
                addDrawableChild(Ui.toggle(colX(1), top + 24, COL_W, "wynlyrics.opt.line_fill", () -> c.lineFill, v -> c.lineFill = v));
            }
            case WORLD -> {
                addDrawableChild(Ui.toggle(colX(0), top, COL_W, "wynlyrics.opt.hud3d", () -> c.hud3dEnabled, v -> c.hud3dEnabled = v));
                addDrawableChild(Ui.cycle(colX(1), top, COL_W, "wynlyrics.opt.w_mode", List.of("follow", "anchored"),
                        () -> c.world3dMode, v -> c.world3dMode = v, v -> Text.translatable("wynlyrics.mode." + v)));
                addDrawableChild(new ConfigSlider(colX(0), top + 24, COL_W, 20, 1, 12, 0.5, () -> c.world3dDistance, v -> c.world3dDistance = (float) v,
                        v -> Ui.labeled("wynlyrics.opt.w_distance", Ui.f(v, 1)), null));
                addDrawableChild(new ConfigSlider(colX(1), top + 24, COL_W, 20, -2, 3, 0.1, () -> c.world3dHeight, v -> c.world3dHeight = (float) v,
                        v -> Ui.labeled("wynlyrics.opt.w_height", Ui.f(v, 1)), null));
                addDrawableChild(new ConfigSlider(colX(0), top + 48, COL_W, 20, 0.3, 4, 0.1, () -> c.world3dScale, v -> c.world3dScale = (float) v,
                        v -> Ui.labeled("wynlyrics.opt.w_scale", Ui.f(v, 1) + "x"), null));
                addDrawableChild(Ui.toggle(colX(1), top + 48, COL_W, "wynlyrics.opt.w_bg", () -> c.world3dBackground, v -> c.world3dBackground = v));
                addDrawableChild(Ui.toggle(colX(0), top + 72, COL_W, "wynlyrics.opt.w_walls", () -> c.world3dThroughWalls, v -> c.world3dThroughWalls = v));
                addDrawableChild(Ui.toggle(colX(1), top + 72, COL_W, "wynlyrics.opt.w_track", () -> c.world3dShowTrack, v -> c.world3dShowTrack = v));
                addDrawableChild(Ui.button(colX(0), top + 96, 312, Text.translatable("wynlyrics.opt.w_pin"), () -> {
                    WorldLyricsRenderer.pinHere();
                    clearAndInit();
                }));
            }
        }

        // footer
        int fy = height - 26;
        addDrawableChild(Ui.button(cx - 156, fy, 102, Text.translatable("wynlyrics.opt.hud_editor"),
                () -> { WynConfig.save(); client.setScreen(new HudEditorScreen(this)); }));
        addDrawableChild(Ui.button(cx - 51, fy, 102, Text.translatable("wynlyrics.opt.cosmetic"),
                () -> { WynConfig.save(); client.setScreen(new CosmeticEditorScreen(this)); }));
        addDrawableChild(Ui.button(cx + 54, fy, 102, Text.translatable("wynlyrics.opt.done"), this::close));
    }

    private void initSpotify(Config c, int top) {
        addDrawableChild(Ui.toggle(colX(0), top, 312, "wynlyrics.opt.spotify", () -> c.spotifyEnabled, v -> c.spotifyEnabled = v));

        clientIdField = new TextFieldWidget(textRenderer, colX(0), top + 24, 312, 20, Text.translatable("wynlyrics.opt.client_id"));
        clientIdField.setMaxLength(64);
        clientIdField.setText(c.spotifyClientId);
        clientIdField.setChangedListener(s -> {
            c.spotifyClientId = s.trim();
            WynConfig.save();
        });
        addDrawableChild(clientIdField);

        SpotifyAuth.State st = SpotifyAuth.state();
        boolean waiting = st == SpotifyAuth.State.WAITING || st == SpotifyAuth.State.EXCHANGING;
        ButtonWidget login = Ui.button(colX(0), top + 48, COL_W,
                Text.translatable(waiting ? "wynlyrics.opt.cancel" : "wynlyrics.opt.login"), () -> {
                    if (SpotifyAuth.state() == SpotifyAuth.State.WAITING || SpotifyAuth.state() == SpotifyAuth.State.EXCHANGING) SpotifyAuth.cancel();
                    else SpotifyAuth.startLogin();
                    clearAndInit();
                });
        login.active = waiting || !c.spotifyClientId.isBlank();
        addDrawableChild(login);

        ButtonWidget logout = Ui.button(colX(1), top + 48, COL_W, Text.translatable("wynlyrics.opt.logout"), () -> {
            SpotifyAuth.logout();
            clearAndInit();
        });
        logout.active = SpotifyAuth.isLoggedIn();
        addDrawableChild(logout);

        ButtonWidget copy = Ui.button(colX(0), top + 72, COL_W, Text.translatable("wynlyrics.opt.copy_link"), SpotifyAuth::copyLink);
        copy.active = st == SpotifyAuth.State.WAITING;
        addDrawableChild(copy);

        addDrawableChild(Ui.button(colX(1), top + 72, COL_W, Text.translatable("wynlyrics.opt.open_folder"),
                () -> Util.getOperatingSystem().open(FabricPaths.dir().toFile())));
    }

    @Override
    public void tick() {
        super.tick();
        if (tab == Tab.SPOTIFY && SpotifyAuth.state() != shownState) clearAndInit();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // draws the background itself
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 6, 0x55D6FF);

        if (tab == Tab.SPOTIFY) {
            int top = 48;
            SpotifyAuth.State st = SpotifyAuth.state();
            String msg = SpotifyAuth.message();
            Text status = Text.translatable("wynlyrics.spotify.state." + st.name().toLowerCase());
            if (!msg.isEmpty()) status = status.copy().append(Text.literal(" \u2014 " + msg));
            int color = switch (st) {
                case LOGGED_IN -> 0x55FF8A;
                case ERROR -> 0xFF6B6B;
                case WAITING, EXCHANGING -> 0xFFD166;
                default -> 0xAAAAAA;
            };
            ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, top + 100, color);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.translatable("wynlyrics.spotify.redirect_hint", SpotifyAuth.redirectUri()), width / 2, top + 114, 0x888888);
            if (clientIdField != null && clientIdField.getText().isEmpty() && !clientIdField.isFocused()) {
                ctx.drawTextWithShadow(textRenderer, Text.translatable("wynlyrics.opt.client_id_hint"),
                        clientIdField.getX() + 4, clientIdField.getY() + 6, 0x666666);
            }
        }
    }

    @Override
    public void removed() { WynConfig.save(); }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }
}
