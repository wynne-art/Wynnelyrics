package com.wynlyrics.render;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    private Draw() {}

    /** Filled rectangle with rounded corners (stacked 1px slices). */
    public static void fillRounded(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        int w = x2 - x1, h = y2 - y1;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { ctx.fill(x1, y1, x2, y2, color); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = (int) Math.round(r - Math.sqrt(r * (double) r - dy * dy));
            ctx.fill(x1 + dx, y1 + i, x2 - dx, y1 + i + 1, color);
            ctx.fill(x1 + dx, y2 - i - 1, x2 - dx, y2 - i, color);
        }
        ctx.fill(x1, y1 + r, x2, y2 - r, color);
    }

    public static String time(long ms) {
        long s = Math.max(0, ms) / 1000;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }
}
