package com.wynlyrics.render;

import com.wynlyrics.config.WynConfig;
import com.wynlyrics.config.WynConfig.Config;
import com.wynlyrics.lyrics.LrcPlayer;
import com.wynlyrics.lyrics.LyricSource;
import com.wynlyrics.lyrics.LyricView;
import com.wynlyrics.util.ColorUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

/** Draws billboarded floating lyrics in the world (Fabric WorldRenderEvents.LAST). */
public final class WorldLyricsRenderer {
    private static final float LINE_H = 12f;
    private static float vis = 0f;
    private static long lastNs = System.nanoTime();
    private static float smoothYaw;
    private static boolean yawInit = false;
    private static Vec3d lastCamPos = Vec3d.ZERO;

    private WorldLyricsRenderer() {}

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = WynConfig.CONFIG;
        if (mc.player == null || mc.world == null || ctx.matrixStack() == null) return;

        long ns = System.nanoTime();
        float dtMs = Math.min(100f, (ns - lastNs) / 1_000_000f);
        lastNs = ns;

        boolean wants = c.hud3dEnabled && !(c.hideWhenIdle && LrcPlayer.INSTANCE.isIdle());
        float step = c.hudFadeMs <= 0 ? 1f : dtMs / c.hudFadeMs;
        vis = wants ? Math.min(1f, vis + step) : Math.max(0f, vis - step);

        Camera cam = ctx.camera();
        Vec3d camPos = cam.getPos();
        lastCamPos = camPos;

        // smooth yaw so the follow mode drifts instead of snapping
        float yaw = cam.getYaw();
        if (!yawInit) { smoothYaw = yaw; yawInit = true; }
        float diff = MathHelper.wrapDegrees(yaw - smoothYaw);
        smoothYaw += diff * (1f - (float) Math.exp(-dtMs / 1000f * 7f));

        if (vis <= 0.01f) return;

        Vec3d pos = followPosition(camPos, c);
        if ("anchored".equals(c.world3dMode) && c.anchorSet
                && c.anchorDimension.equals(mc.world.getRegistryKey().getValue().toString())) {
            pos = new Vec3d(c.anchorX, c.anchorY, c.anchorZ);
            if (pos.squaredDistanceTo(camPos) > 96 * 96) return;
        }

        TextRenderer tr = mc.textRenderer;
        VertexConsumerProvider.Immediate vcp = mc.getBufferBuilders().getEntityVertexConsumers();
        MatrixStack m = ctx.matrixStack();
        LyricSource src = LrcPlayer.INSTANCE;

        m.push();
        m.translate(pos.x - camPos.x, pos.y - camPos.y, pos.z - camPos.z);
        m.multiply(cam.getRotation());
        float s = 0.025f * c.world3dScale;
        m.scale(-s, -s, s);

        TextRenderer.TextLayerType layer = c.world3dThroughWalls
                ? TextRenderer.TextLayerType.SEE_THROUGH : TextRenderer.TextLayerType.NORMAL;

        List<LyricView.Item> items = HudRenderer.LIVE.compute(HudRenderer.params(), System.currentTimeMillis());

        if (c.world3dShowTrack && !src.title().isBlank()) {
            String head = src.title() + (c.showArtist && !src.artist().isBlank() ? "  \u2022  " + src.artist() : "");
            drawText(m, vcp, tr, head, -(c.linesBefore + 1.6f), 0.65f, c.accentColor, vis, layer);
        }
        if (items.isEmpty()) {
            String key = src.statusKey();
            if (!key.isEmpty()) {
                drawText(m, vcp, tr, "\u266A  " + net.minecraft.client.resource.language.I18n.translate(key),
                        0f, 0.9f, c.inactiveColor, vis, layer);
            }
        }
        for (LyricView.Item it : items) {
            float alpha = it.alpha() * vis;
            if (alpha < 0.03f) continue;
            int rgb = it.fill() >= 0f ? ColorUtil.lerpRgb(c.textColor, c.accentColor, it.fill()) : it.rgb();
            drawText(m, vcp, tr, it.text(), it.slot(), it.scale(), rgb, alpha, layer);
        }
        m.pop();
        vcp.draw();
    }

    private static void drawText(MatrixStack m, VertexConsumerProvider vcp, TextRenderer tr, String str,
                                 float slot, float scale, int rgb, float alpha, TextRenderer.TextLayerType layer) {
        Config c = WynConfig.CONFIG;
        Text text = FontRegistry.text(str);
        float w = tr.getWidth(text);
        float sc = scale;
        if (w * sc > 260f) sc = 260f / w;
        m.push();
        m.translate(0f, slot * LINE_H, 0f);
        m.scale(sc, sc, 1f);
        Matrix4f mat = m.peek().getPositionMatrix();
        int col = ColorUtil.argb(rgb, alpha);
        int bg = c.world3dBackground ? ColorUtil.argb(c.backgroundColor, c.backgroundOpacity * alpha) : 0;
        if (c.textOutline) {
            tr.drawWithOutline(text.asOrderedText(), -w / 2f, 0f, col, ColorUtil.argb(c.outlineColor, alpha),
                    mat, vcp, LightmapTextureManager.MAX_LIGHT_COORDINATE);
        } else {
            tr.draw(text, -w / 2f, 0f, col, c.textShadow, mat, vcp, layer, bg, LightmapTextureManager.MAX_LIGHT_COORDINATE);
        }
        m.pop();
    }

    private static Vec3d followPosition(Vec3d camPos, Config c) {
        double rad = Math.toRadians(smoothYaw);
        return new Vec3d(camPos.x - Math.sin(rad) * c.world3dDistance,
                camPos.y + c.world3dHeight,
                camPos.z + Math.cos(rad) * c.world3dDistance);
    }

    /** Stores the current floating position as the anchor and switches to anchored mode. */
    public static void pinHere() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = WynConfig.CONFIG;
        if (mc.player == null || mc.world == null) return;
        Vec3d p = followPosition(mc.gameRenderer.getCamera().getPos(), c);
        c.anchorX = p.x; c.anchorY = p.y; c.anchorZ = p.z;
        c.anchorDimension = mc.world.getRegistryKey().getValue().toString();
        c.anchorSet = true;
        c.world3dMode = "anchored";
        WynConfig.save();
    }
}
