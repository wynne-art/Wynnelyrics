package com.wynlyrics.spotify;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/** Minimal HTTP helper on java.base only (the Minecraft runtime may lack java.net.http). */
public final class Http {
    public record Response(int code, String body, Map<String, List<String>> headers) {
        public String header(String name) {
            for (Map.Entry<String, List<String>> e : headers.entrySet()) {
                if (e.getKey() != null && e.getKey().equalsIgnoreCase(name) && !e.getValue().isEmpty()) return e.getValue().get(0);
            }
            return null;
        }
    }

    private Http() {}

    public static Response get(String url, Map<String, String> headers, int timeoutMs) throws IOException {
        HttpURLConnection c = open(url, timeoutMs);
        c.setRequestMethod("GET");
        for (Map.Entry<String, String> h : headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
        return exec(c);
    }

    public static Response postForm(String url, Map<String, String> form, int timeoutMs) throws IOException {
        HttpURLConnection c = open(url, timeoutMs);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : form.entrySet()) {
            if (sb.length() > 0) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8)).append('=')
              .append(URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8));
        }
        byte[] body = sb.toString().getBytes(StandardCharsets.UTF_8);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        c.setFixedLengthStreamingMode(body.length);
        c.getOutputStream().write(body);
        return exec(c);
    }

    private static HttpURLConnection open(String url, int timeoutMs) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(timeoutMs);
        c.setReadTimeout(timeoutMs);
        c.setRequestProperty("User-Agent", "WynLyrics/1.0");
        c.setRequestProperty("Accept", "application/json");
        return c;
    }

    private static Response exec(HttpURLConnection c) throws IOException {
        try {
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = "";
            if (in != null) {
                try (in) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    in.transferTo(out);
                    body = out.toString(StandardCharsets.UTF_8);
                }
            }
            return new Response(code, body, c.getHeaderFields());
        } finally {
            c.disconnect();
        }
    }
}
