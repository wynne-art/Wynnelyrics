package com.wynlyrics.spotify;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wynlyrics.WynLyricsClient;
import com.wynlyrics.config.WynConfig;
import com.wynlyrics.lyrics.LrcPlayer;

import java.io.IOException;
import java.util.Map;

/** Polls Spotify's currently-playing endpoint (every ~2.5 s) on a worker thread. */
public final class SpotifyClient {
    private static final String URL =
            "https://api.spotify.com/v1/me/player/currently-playing?additional_types=track,episode";
    private static volatile long nextPoll = 0;
    private static volatile boolean running = false;

    private SpotifyClient() {}

    public static void tick() {
        if (!WynConfig.CONFIG.spotifyEnabled) return;
        long now = System.currentTimeMillis();
        if (now < nextPoll || running) return;
        nextPoll = now + 2500;
        running = true;
        Thread t = new Thread(SpotifyClient::poll, "WynLyrics-Spotify");
        t.setDaemon(true);
        t.start();
    }

    private static void poll() {
        try {
            String token = SpotifyAuth.validToken();
            if (token == null) {
                String legacy = WynConfig.CONFIG.spotifyAccessToken;
                if (legacy != null && !legacy.isBlank()) token = legacy.trim();
            }
            if (token == null) { nextPoll = System.currentTimeMillis() + 5000; return; }

            Http.Response r = Http.get(URL, Map.of("Authorization", "Bearer " + token), 8000);
            switch (r.code()) {
                case 200 -> parse(r.body());
                case 204 -> LrcPlayer.INSTANCE.applyIdle();
                case 401 -> { SpotifyAuth.invalidateAccess(); nextPoll = System.currentTimeMillis() + 1000; }
                case 429 -> {
                    int wait = 5;
                    try { String h = r.header("Retry-After"); if (h != null) wait = Integer.parseInt(h.trim()); }
                    catch (NumberFormatException ignored) {}
                    nextPoll = System.currentTimeMillis() + Math.max(1, wait) * 1000L;
                }
                default -> {
                    WynLyricsClient.LOGGER.warn("Spotify returned HTTP {}", r.code());
                    nextPoll = System.currentTimeMillis() + 5000;
                }
            }
        } catch (IOException e) {
            WynLyricsClient.LOGGER.warn("Spotify request failed: {}", e.getMessage());
            nextPoll = System.currentTimeMillis() + 5000;
        } catch (RuntimeException e) {
            WynLyricsClient.LOGGER.warn("Spotify response could not be parsed: {}", e.toString());
        } finally {
            running = false;
        }
    }

    private static void parse(String body) {
        if (body == null || body.isBlank()) { LrcPlayer.INSTANCE.applyIdle(); return; }
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        JsonElement itemEl = root.get("item");
        if (itemEl == null || itemEl.isJsonNull()) { LrcPlayer.INSTANCE.applyIdle(); return; }
        JsonObject item = itemEl.getAsJsonObject();

        String title = item.has("name") ? item.get("name").getAsString() : "Unknown";
        StringBuilder artists = new StringBuilder();
        if (item.has("artists") && item.get("artists").isJsonArray()) {
            JsonArray arr = item.getAsJsonArray("artists");
            for (JsonElement a : arr) {
                if (artists.length() > 0) artists.append(", ");
                artists.append(a.getAsJsonObject().get("name").getAsString());
            }
        } else if (item.has("show") && item.get("show").isJsonObject()) {
            artists.append(item.getAsJsonObject("show").get("name").getAsString());
        }
        long progress = root.has("progress_ms") && !root.get("progress_ms").isJsonNull() ? root.get("progress_ms").getAsLong() : 0;
        long duration = item.has("duration_ms") ? item.get("duration_ms").getAsLong() : 0;
        boolean playing = root.has("is_playing") && root.get("is_playing").getAsBoolean();
        LrcPlayer.INSTANCE.applySpotify(title, artists.toString(), progress, duration, playing);
    }
}
