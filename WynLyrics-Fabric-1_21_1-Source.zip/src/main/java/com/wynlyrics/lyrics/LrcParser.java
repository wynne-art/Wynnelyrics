package com.wynlyrics.lyrics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure LRC parser (no Minecraft dependency, unit-testable). */
public final class LrcParser {
    private static final Pattern TIMESTAMP = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");
    private static final Pattern TAG = Pattern.compile("^\\s*\\[([a-zA-Z]+):([^\\]]*)]\\s*$");
    private static final Pattern WORD_TAG = Pattern.compile("<\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?>");

    private LrcParser() {}

    public static LrcData parse(Iterable<String> rawLines) {
        List<LrcLine> out = new ArrayList<>();
        long offset = 0;
        String title = "", artist = "";
        boolean first = true;
        for (String raw : rawLines) {
            if (raw == null) continue;
            if (first) { first = false; if (!raw.isEmpty() && raw.charAt(0) == '\uFEFF') raw = raw.substring(1); }
            Matcher tag = TAG.matcher(raw);
            if (tag.matches()) {
                String key = tag.group(1).toLowerCase();
                String val = tag.group(2).trim();
                switch (key) {
                    case "ti" -> title = val;
                    case "ar" -> artist = val;
                    case "offset" -> {
                        try { offset = Long.parseLong(val.startsWith("+") ? val.substring(1) : val); }
                        catch (NumberFormatException ignored) {}
                    }
                    default -> {}
                }
                continue;
            }
            Matcher times = TIMESTAMP.matcher(raw);
            List<Long> stamps = new ArrayList<>();
            while (times.find()) {
                long min = Long.parseLong(times.group(1));
                long sec = Long.parseLong(times.group(2));
                String fraction = times.group(3);
                long millis = fraction == null ? 0 : Long.parseLong((fraction + "00").substring(0, 3));
                stamps.add((min * 60 + sec) * 1000 + millis);
            }
            if (stamps.isEmpty()) continue;
            String lyric = TIMESTAMP.matcher(raw).replaceAll("");
            lyric = WORD_TAG.matcher(lyric).replaceAll("").trim();
            for (long t : stamps) out.add(new LrcLine(t, lyric));
        }
        out.sort(Comparator.comparingLong(LrcLine::timeMs));
        return new LrcData(List.copyOf(out), offset, title, artist);
    }
}
