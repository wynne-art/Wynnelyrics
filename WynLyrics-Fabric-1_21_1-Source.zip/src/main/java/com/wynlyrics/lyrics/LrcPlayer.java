package com.wynlyrics.lyrics;

import com.wynlyrics.WynLyricsClient;
import com.wynlyrics.config.WynConfig;
import com.wynlyrics.spotify.SpotifyClient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Live lyric state: current track, playback clock and parsed LRC. */
public final class LrcPlayer implements LyricSource {
    public static final LrcPlayer INSTANCE = new LrcPlayer();

    private volatile LrcData data = LrcData.EMPTY;
    private volatile String title = "";
    private volatile String artist = "";
    private volatile long durationMs = 0;
    private volatile boolean playing = true;
    private volatile boolean hasTrack = false;
    private volatile boolean external = false;
    private volatile long anchorPos = 0;
    private volatile long anchorTime = System.currentTimeMillis();
    private volatile long localStart = System.currentTimeMillis();
    private String loadedKey = "";

    private LrcPlayer() {}

    // ------------------------------------------------------------ lifecycle

    public void init() {
        FabricPaths.dir();
        external = WynConfig.CONFIG.spotifyEnabled;
        if (!external) loadLocalFile();
    }

    public void tick() {
        SpotifyClient.tick();
        boolean ext = WynConfig.CONFIG.spotifyEnabled;
        if (ext != external) {
            external = ext;
            hasTrack = false;
            loadedKey = "";
            title = ""; artist = ""; durationMs = 0;
            if (ext) data = LrcData.EMPTY;
            else loadLocalFile();
        }
    }

    // ------------------------------------------------------------ loading

    public void reload() {
        if (external) {
            if (hasTrack) loadForTrack(title, artist);
        } else {
            loadLocalFile();
        }
    }

    private void loadLocalFile() {
        localStart = System.currentTimeMillis();
        Path p = FabricPaths.resolveLrc(WynConfig.CONFIG.lyricsFile);
        data = p != null && Files.exists(p) ? read(p) : LrcData.EMPTY;
        title = data.title();
        artist = data.artist();
    }

    private void loadForTrack(String t, String a) {
        data = LrcData.EMPTY;
        if (!WynConfig.CONFIG.useSpotifyLyricsFile) {
            Path p = FabricPaths.resolveLrc(WynConfig.CONFIG.lyricsFile);
            if (p != null && Files.exists(p)) data = read(p);
            return;
        }
        for (String name : new String[]{a + " - " + t, t}) {
            Path p = FabricPaths.resolveLrc(name);
            if (p != null && Files.exists(p)) { data = read(p); return; }
        }
    }

    private static LrcData read(Path path) {
        try {
            List<String> lines = Files.readAllLines(path);
            return LrcParser.parse(lines);
        } catch (IOException e) {
            WynLyricsClient.LOGGER.warn("Could not read LRC {}: {}", path, e.getMessage());
            return LrcData.EMPTY;
        }
    }

    // ------------------------------------------------------------ Spotify input

    public synchronized void applySpotify(String t, String a, long progress, long duration, boolean isPlaying) {
        long now = System.currentTimeMillis();
        String key = t + "\u0000" + a + "\u0000" + duration;
        if (!key.equals(loadedKey)) {
            loadedKey = key;
            title = t; artist = a;
            durationMs = Math.max(0, duration);
            hasTrack = true;
            loadForTrack(t, a);
            anchorPos = progress; anchorTime = now;
        } else {
            boolean resumed = isPlaying && !playing;
            long expected = positionMs();
            if (resumed || !isPlaying || Math.abs(progress - expected) > 350) {
                anchorPos = progress; anchorTime = now;
            }
        }
        playing = isPlaying;
    }

    public synchronized void applyIdle() {
        if (hasTrack) {
            anchorPos = positionMs();
            anchorTime = System.currentTimeMillis();
        }
        playing = false;
    }

    // ------------------------------------------------------------ LyricSource

    public boolean isExternal() { return external; }

    /** True when there is nothing meaningful to show. */
    public boolean isIdle() { return external ? !hasTrack : data.lines().isEmpty(); }

    @Override public String title() { return title; }
    @Override public String artist() { return artist; }
    @Override public long durationMs() { return durationMs; }

    @Override public long positionMs() {
        long now = System.currentTimeMillis();
        if (!external) return Math.max(0, now - localStart);
        if (!hasTrack) return 0;
        long p = playing ? anchorPos + (now - anchorTime) : anchorPos;
        return durationMs > 0 ? Math.min(p, durationMs) : Math.max(0, p);
    }

    private long adjustedPosition() {
        return positionMs() + data.offsetMs() + WynConfig.CONFIG.lyricsOffsetMs;
    }

    @Override public int lineCount() { return data.lines().size(); }

    @Override public String lineText(int i) { return data.lines().get(i).text(); }

    @Override public int currentIndex() {
        List<LrcLine> lines = data.lines();
        long p = adjustedPosition();
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).timeMs() <= p) { ans = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return ans;
    }

    @Override public float lineProgress(int i) {
        List<LrcLine> lines = data.lines();
        if (i < 0 || i >= lines.size()) return 0f;
        long start = lines.get(i).timeMs();
        long end = i + 1 < lines.size() ? lines.get(i + 1).timeMs() : start + 4000;
        long window = Math.min(end - start, Math.max(1500L, lines.get(i).text().length() * 200L));
        if (window <= 0) return 1f;
        float f = (adjustedPosition() - start) / (float) window;
        return f < 0f ? 0f : Math.min(f, 1f);
    }

    @Override public boolean hasLyrics() { return !data.lines().isEmpty(); }

    @Override public String statusKey() {
        if (hasLyrics()) return "";
        return external && !hasTrack ? "wynlyrics.status.waiting" : "wynlyrics.status.no_lyrics";
    }
}
