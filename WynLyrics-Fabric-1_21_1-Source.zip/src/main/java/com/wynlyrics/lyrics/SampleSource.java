package com.wynlyrics.lyrics;

/** Looping fake song used by the HUD and cosmetic editors. */
public final class SampleSource implements LyricSource {
    private static final long LINE_MS = 2800;
    private final String[] lines;
    private final long start = System.currentTimeMillis();

    public SampleSource(String[] lines) { this.lines = lines; }

    @Override public String title() { return "Sample Track"; }
    @Override public String artist() { return "WynLyrics"; }
    @Override public long durationMs() { return lines.length * LINE_MS; }
    @Override public long positionMs() { return (System.currentTimeMillis() - start) % durationMs(); }
    @Override public int lineCount() { return lines.length; }
    @Override public String lineText(int i) { return lines[i]; }
    @Override public int currentIndex() { return (int) (positionMs() / LINE_MS); }
    @Override public float lineProgress(int i) { return (positionMs() % LINE_MS) / (float) LINE_MS; }
    @Override public boolean hasLyrics() { return true; }
    @Override public String statusKey() { return ""; }
}
