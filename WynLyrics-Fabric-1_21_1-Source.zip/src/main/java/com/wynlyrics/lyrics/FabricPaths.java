package com.wynlyrics.lyrics;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public final class FabricPaths {
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("wynlyrics").normalize();

    private FabricPaths() {}

    public static Path dir() {
        try { Files.createDirectories(DIR); } catch (IOException ignored) {}
        return DIR;
    }

    /** Replaces characters Windows/Linux file systems reject; keeps non-ASCII letters. */
    public static String sanitize(String s) {
        if (s == null) return "";
        String safe = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim().replaceAll("^\\.+", "");
        return safe.length() > 120 ? safe.substring(0, 120).trim() : safe;
    }

    /** Resolves "<name>.lrc" inside the lyrics folder, or null if the name is unsafe/empty. */
    public static Path resolveLrc(String baseName) {
        String safe = sanitize(baseName);
        if (safe.isEmpty()) return null;
        String file = safe.toLowerCase(Locale.ROOT).endsWith(".lrc") ? safe : safe + ".lrc";
        Path p = DIR.resolve(file).normalize();
        return p.startsWith(DIR) ? p : null;
    }
}
