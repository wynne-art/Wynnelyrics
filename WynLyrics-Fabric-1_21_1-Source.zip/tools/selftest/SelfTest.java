import com.wynlyrics.lyrics.*;
import com.wynlyrics.spotify.Pkce;
import com.wynlyrics.util.ColorUtil;

import java.util.List;

/** Plain-Java checks for the Minecraft-independent logic. Run: tools/selftest/run.sh */
public final class SelfTest {
    static int failed = 0;
    static void check(boolean ok, String name) {
        System.out.println((ok ? "PASS " : "FAIL ") + name);
        if (!ok) failed++;
    }

    /** Fake clock-driven source for LyricView. */
    static final class Fake implements LyricSource {
        final LrcData d; long pos; String t = "T";
        Fake(LrcData d) { this.d = d; }
        public String title() { return t; } public String artist() { return "A"; }
        public long durationMs() { return 60000; } public long positionMs() { return pos; }
        public int lineCount() { return d.lines().size(); }
        public String lineText(int i) { return d.lines().get(i).text(); }
        public int currentIndex() {
            int a = -1;
            for (int i = 0; i < d.lines().size(); i++) if (d.lines().get(i).timeMs() <= pos) a = i;
            return a;
        }
        public float lineProgress(int i) { return 0.5f; }
        public boolean hasLyrics() { return lineCount() > 0; }
        public String statusKey() { return ""; }
    }

    public static void main(String[] a) {
        // ---- LRC parser
        LrcData d = LrcParser.parse(List.of(
                "\uFEFF[ti:Song]", "[ar:Band]", "[offset:+250]",
                "[00:02.50]First", "[00:06.00][00:20.5]Repeated", "[01:05.123]<00:65.00>Word <00:66.00>tags",
                "[00:09]No fraction", "no timestamp line", "[00:12.00]"));
        check(d.title().equals("Song") && d.artist().equals("Band"), "metadata tags");
        check(d.offsetMs() == 250, "offset tag");
        check(d.lines().size() == 6, "line count (multi-timestamp expanded) = " + d.lines().size());
        check(d.lines().get(0).timeMs() == 2500, "fraction .50 -> 2500ms");
        check(d.lines().get(1).text().equals("Repeated") && d.lines().get(1).timeMs() == 6000, "multi timestamp 1");
        check(d.lines().get(2).timeMs() == 9000 && d.lines().get(2).text().equals("No fraction"), "no fraction + sorted");
        check(d.lines().get(4).timeMs() == 20500, "[00:20.5] -> 20500");
        check(d.lines().get(5).timeMs() == 65123 && d.lines().get(5).text().equals("Word tags"), "word tags stripped, 3-digit fraction");
        check(d.lines().get(3).text().isEmpty(), "blank lyric line kept");
        check(LrcParser.parse(List.of("[00:01.00]x", "[bad")).lines().size() == 1, "malformed ignored");

        // ---- PKCE (RFC 7636 appendix B vector)
        check(Pkce.challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk").equals("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"), "PKCE RFC vector");
        String v = Pkce.verifier();
        check(v.length() >= 43 && v.length() <= 128 && v.matches("[A-Za-z0-9_-]+"), "verifier length/charset (" + v.length() + ")");
        check(!Pkce.verifier().equals(Pkce.verifier()), "verifier random");

        // ---- color helpers
        check(ColorUtil.parseHex("#55D6FF") == 0x55D6FF && ColorUtil.parseHex("fff") == 0xFFFFFF, "parseHex");
        check(ColorUtil.parseHex("zzz") == -1 && ColorUtil.parseHex("#12") == -1, "parseHex invalid");
        check(ColorUtil.hex(0xABCDEF).equals("#ABCDEF"), "hex");
        check(ColorUtil.lerpRgb(0x000000, 0xFFFFFF, 0.5f) == 0x808080, "lerpRgb");
        check((ColorUtil.argb(0xFF0000, 0.5f) >>> 24) == 128, "argb alpha");

        // ---- LyricView
        LrcData song = LrcParser.parse(List.of("[00:01.00]One", "[00:03.00]Two", "[00:05.00]Three", "[00:07.00]Four"));
        Fake f = new Fake(song);
        LyricView v1 = new LyricView(f);
        LyricView.Params slide = new LyricView.Params(1, 1, "slide", 400, 0.5f, true, 0xFFFFFF, 0x888888);
        long t0 = 1_000_000L;
        f.pos = 3500;
        List<LyricView.Item> items = v1.compute(slide, t0);
        check(items.stream().anyMatch(i -> i.current() && i.text().equals("Two") && Math.abs(i.slot()) < 0.01f), "settled: current line at slot 0");
        f.pos = 5500;
        items = v1.compute(slide, t0 + 10);
        LyricView.Item cur = items.stream().filter(LyricView.Item::current).findFirst().orElseThrow();
        check(cur.text().equals("Three") && cur.slot() > 0.8f, "just changed: new line starts one slot below (" + cur.slot() + ")");
        LyricView.Item prev = items.stream().filter(i -> i.text().equals("Two")).findFirst().orElseThrow();
        check(Math.abs(prev.slot()) < 0.2f && prev.alpha() > 0.7f, "just changed: previous line still near center");
        items = v1.compute(slide, t0 + 10 + 500);
        cur = items.stream().filter(LyricView.Item::current).findFirst().orElseThrow();
        check(Math.abs(cur.slot()) < 0.001f, "after animMs: slot 0");
        check(cur.fill() == 0.5f, "karaoke fill comes from source");

        LyricView.Params none = new LyricView.Params(0, 1, "none", 0, 0.5f, false, 0xFFFFFF, 0x888888);
        f.pos = 1500;
        items = new LyricView(f).compute(none, t0);
        check(items.stream().filter(i -> i.alpha() > 0.01f).count() == 2 && items.stream().allMatch(i -> i.fill() < 0), "none/no fill: current + next visible, extra slot invisible");

        f.pos = 100; // before first line
        items = new LyricView(f).compute(slide, t0);
        check(items.stream().anyMatch(i -> i.text().equals("\u266A") && i.current()), "before first line shows note placeholder");
        check(items.stream().anyMatch(i -> i.text().equals("One")), "before first line still shows upcoming line");

        LyricView.Params tw = new LyricView.Params(0, 0, "typewriter", 300, 0.5f, false, 0xFFFFFF, 0x888888);
        f.pos = 3500;
        LyricView typeView = new LyricView(f);
        typeView.compute(tw, t0);
        f.pos = 5500;
        items = typeView.compute(tw, t0 + 100);
        check(items.stream().filter(LyricView.Item::current).findFirst().orElseThrow().text().length() < "Three".length(), "typewriter reveals partially");
        items = typeView.compute(tw, t0 + 5000);
        check(items.stream().filter(LyricView.Item::current).findFirst().orElseThrow().text().equals("Three"), "typewriter completes");

        // backwards seek must not crash and must flip direction
        f.pos = 1500;
        items = typeView.compute(slide, t0 + 6000);
        check(!items.isEmpty(), "backward seek ok");

        System.out.println(failed == 0 ? "\nALL PASSED" : "\n" + failed + " FAILED");
        System.exit(failed == 0 ? 0 : 1);
    }
}
